# Integ.Life UI

A small shared React shell and CSS token package, first consumed by Things and Tools.

## MVP card

- Target user: a person moving between Integ.Life products on desktop or phone.
- Job: recognize the product, switch products, navigate locally and finish an existing task.
- Riskiest assumption: the same shell can support a signed-in inventory workspace and anonymous utility catalog without crowding mobile controls or disrupting existing workflows.
- P1 loop: open Things, navigate and inspect an item; switch to Tools, find and run JSON Formatter; change language and appearance without losing the working content.
- Representative conditions: desktop and 390px mobile, keyboard, light/dark, Chinese/English and existing RTL Tools locale.
- Success proof: both products bundle the exact same package; real public versions and browser interaction match the verified builds.
- No-gos: cross-site session changes, data migrations, unrelated home-model changes, camera behavior changes, invented account or notification capabilities.
- Appetite: family header/product switcher, appearance control, accessible mobile navigation and shared geometry/tokens in two consumers.
- Later: remaining products, notification aggregation, cross-origin preference synchronization and general component-library expansion.

## Distribution

Run `npm pack` and commit the versioned tarball to each consumer's `vendor/` directory.
Consumers install a `file:` dependency and bundle it locally; CI needs no private
registry credential, and a shell release cannot change another site implicitly.
The package version is recorded in each product's build-version.json. Source
changes require a new version and an explicit consumer upgrade.

React and React DOM are host peer dependencies. The shell owns presentation and
non-secret origin-local appearance preferences; products own locale selection,
routing, authentication, data, and authorization.
