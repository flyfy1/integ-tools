const keys = ['products','close','appearance','system','light','dark','account','manageAccount','navigation','home'];
const rows = {
 en:['Switch product','Close','Appearance','System','Light','Dark','Account','Manage account','Navigation','Integ.Life home'],
 zh:['切换产品','关闭','外观','跟随系统','浅色','深色','账户','管理账户','导航','Integ.Life 首页'],
 es:['Cambiar producto','Cerrar','Apariencia','Sistema','Claro','Oscuro','Cuenta','Gestionar cuenta','Navegación','Inicio de Integ.Life'],
 fr:['Changer de produit','Fermer','Apparence','Système','Clair','Sombre','Compte','Gérer le compte','Navigation','Accueil Integ.Life'],
 de:['Produkt wechseln','Schließen','Darstellung','System','Hell','Dunkel','Konto','Konto verwalten','Navigation','Integ.Life Startseite'],
 id:['Ganti produk','Tutup','Tampilan','Sistem','Terang','Gelap','Akun','Kelola akun','Navigasi','Beranda Integ.Life'],
 vi:['Chuyển sản phẩm','Đóng','Giao diện','Hệ thống','Sáng','Tối','Tài khoản','Quản lý tài khoản','Điều hướng','Trang chủ Integ.Life'],
 th:['สลับผลิตภัณฑ์','ปิด','รูปแบบ','ระบบ','สว่าง','มืด','บัญชี','จัดการบัญชี','การนำทาง','หน้าหลัก Integ.Life'],
 ja:['製品を切り替え','閉じる','外観','システム','ライト','ダーク','アカウント','アカウント管理','ナビゲーション','Integ.Life ホーム'],
 ko:['제품 전환','닫기','화면 모드','시스템','라이트','다크','계정','계정 관리','탐색','Integ.Life 홈'],
 hi:['उत्पाद बदलें','बंद करें','दिखावट','सिस्टम','हल्का','गहरा','खाता','खाता प्रबंधन','नेविगेशन','Integ.Life होम'],
 ar:['تبديل المنتج','إغلاق','المظهر','النظام','فاتح','داكن','الحساب','إدارة الحساب','التنقل','الرئيسية Integ.Life'],
};
export function shellLabels(locale = 'en') { const row=rows[locale.toLowerCase().split('-')[0]] || rows.en; return Object.fromEntries(keys.map((key,i)=>[key,row[i]])); }
export const products = [
 {id:'app',name:'Integ.Life',description:'Notes · Todo · People · Money · Calendar',href:'https://app.integ.life/'},
 {id:'things',name:'Things',description:'things.integ.life',href:'https://things.integ.life/'},
 {id:'chat',name:'Integ.Chat',description:'chat.integ.life',href:'https://chat.integ.life/'},
 {id:'lingulet',name:'Lingulet',description:'lang.integ.life',href:'https://lang.integ.life/'},
 {id:'tools',name:'Integ Tools',description:'tools.integ.life',href:'https://tools.integ.life/'},
 {id:'games',name:'Integ Games',description:'games.integ.life',href:'https://games.integ.life/'},
 {id:'chinese-chess',name:'Chinese Chess',description:'chinese-chess.integ.life',href:'https://chinese-chess.integ.life/'},
 {id:'chess',name:'Chess',description:'chess.integ.life',href:'https://chess.integ.life/'},
 {id:'snake',name:'Snake Arena',description:'snake.integ.life',href:'https://snake.integ.life/'},
 {id:'blog',name:'Field Notes',description:'blog.integ.life',href:'https://blog.integ.life/'},
];
